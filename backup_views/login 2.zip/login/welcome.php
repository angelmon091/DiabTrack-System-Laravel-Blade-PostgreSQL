<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("location: index.html");
    exit();
}

$_username = $_SESSION["username"];
$id_user = $_SESSION["id_user"];
$email = $_SESSION["email"];
$name = $_SESSION["name"];
$_lastname = $_SESSION["lastname"];
$password = $_SESSION["password"];
?>


<!DOCTYPE html>
<html lang="">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Title Page</title>

    <link rel="stylesheet" href="style.css">

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">



    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    
    <nav class="navbar navbar-default" role="navigation">
      <!-- Brand and toggle get grouped for better mobile display -->
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#"><?php echo ($_username); ?></a>
      </div>
    
      <!-- Collect the nav links, forms, and other content for toggling -->
      <!--<div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav">
          <li class="active"><a href="#">Link</a></li>
          <li><a href="#">Link</a></li>
        </ul>
        <form class="navbar-form navbar-left" role="search">
          <div class="form-group">
            <input type="text" class="form-control" placeholder="Search">
          </div>
          <button type="submit" class="btn btn-default">Submit</button>
        </form> -->
        <ul class="nav navbar-nav navbar-right"> 
          <li><a href="logout.php">Log out</a></li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
            <ul class="dropdown-menu">
              <!-- <li><a href="registro.html">Add users</a></li>
              <li><a href="eliminar_usuarios.php">Delete usser</a></li> -->
              <li><a href="crud.php">CRUD</a></li>
              <li><a href="#"></a></li>
            </ul>
          </li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </nav>
    
    <div class="container">
      <?php
        $servername = "localhost";
        $username_db = "root";
        $password_db = "";
        $dbname = "user_db";

        $conn = new mysqli($servername, $username_db, $password_db, $dbname);

        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT name, lastname, email, username FROM users";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
          echo '<table class="table table-striped table-bordered">';
          echo '<thead>';
          echo '<tr>';
          echo '<th>Name</th>';
          echo '<th>Last Name</th>';
          echo '<th>Email</th>';
          echo '<th>Username</th>';
          echo '</tr>';
          echo '</thead>';
          echo '<tbody>';

          while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . ($row['name']) . '</td>';
            echo '<td>' . ($row['lastname']) . '</td>';
            echo '<td>' . ($row['email']) . '</td>';
            echo '<td>' . ($row['username']) . '</td>';
            echo '</tr>';
          }

          echo '</tbody>';
          echo '</table>';
        } else {
          echo '<p>No registered users.</p>';
        }

        $conn->close();
      ?>
    </div>

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </body>
</html>
