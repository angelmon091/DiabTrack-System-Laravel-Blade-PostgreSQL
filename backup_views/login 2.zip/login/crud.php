
<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>CRUD</title>
        <link rel="stylesheet" href="styles.css">

        <!-- Bootstrap CSS 
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">-->

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.3/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>

    <div class="login-card" style="max-width: 900px; padding: 2.5rem;">
        <div class="secondary-link" style="text-align: left; margin-bottom: 1.5rem; margin-top:0;">
            <a href="welcome.php">&larr; Back to Home</a>
        </div>
        
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
            <h1 style="margin: 0;">User Administration</h1>
            <div class="header-actions" style="display: flex; gap: 10px;">
                <button onclick="showAddUser('ModalAgregar')" style="border-radius: 10px;">Add User</button>
            </div>
        </div>

        <div class="admin-table-wrapper">
            <table id="usuariosTable" class="admin-table" border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="tabla-usuarios">
                   
                </tbody>
            </table>
            <div id="ModalEditar" style="display: none;">
                <h3>Edit User</h3>
                <form id="mostrarEditarUsuario">
                    ID : <span id="EditID"></span>
                    <br>
                    <br>
                    Username : <input type="text" id="EditUsername" name="EditUsername">
                    <br>
                    Password : <input type="password" id="EditPassword" name="EditPassword">
                    <br>
                    Name : <input type="text" id="EditName" name="EditName">
                    <br>
                    Lastname : <input type="text" id="EditLastname" name="EditLastname">
                    <br>
                    Email : <input type="email" id="EditEmail" name="EditEmail">
                    <br>
                    <br>
                    <button type="button" onclick="SaveEdition()">Save</button>
                    <button type="button" onclick="hideModal('ModalEditar')">Cancel</button>

                </form>
            </div>

            <div id="ModalAgregar" style="display: none;">
                <h3>Add User</h3>
                <form action="guardar_usuario.php" id="NewUser" method="post">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required><br>
                    <br>
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required><br>
                    <br>
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" required><br>
                    <br>
                    <label for="lastname">Lastname</label>
                    <input type="text" id="lastname" name="lastname" required><br>
                    <br>
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required><br>
                    <br>
                    <button type="submit">Add</button>
                    <button type="button" onclick="hideModal('ModalAgregar')">Cancel</button>
                </form>
            </div>

            <div id="ModalEliminar" style="display: none;">
                <h3>Delete User</h3>
                <form id="mostrarEliminarUsuario">
                    ID : <span id="ElimID"></span>
                    <br>
                    <button type="button" onclick="DeleteUser()">Delete</button>
                    <button type="button" onclick="hideModal('ModalEliminar')">Cancel</button>
                </form>
            </div>

        </div>
    </div>

        <!-- jQuery -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!-- Bootstrap JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

        <script>
            // Logic
            function showAddUser(elementID){
                var element = document.getElementById(elementID);
                if(element) {
                    element.style.display = "block";
                }
            } 

            function hideModal(elementID){
                var element = document.getElementById(elementID);
                if(element) {
                    element.style.display = "none";
                }
            }   
            function showEditUser(id, name, lastname, email, username, password){
                document.getElementById("EditID").textContent = id;
                document.getElementById("EditName").value = name;
                document.getElementById("EditLastname").value = lastname;
                document.getElementById("EditEmail").value = email;
                document.getElementById("EditUsername").value = username;
                document.getElementById("EditPassword").value = password;
                
                document.getElementById("ModalEditar").style.display = "block";
            }
            
            function SaveEdition(){
                var id = document.getElementById('EditID').innerText;
                var name = document.getElementById('EditName').value;
                var lastname = document.getElementById('EditLastname').value;
                var email = document.getElementById('EditEmail').value;
                var username = document.getElementById('EditUsername').value;
                var password = document.getElementById('EditPassword').value;
                
                $.ajax({
                    url: 'guardar_edicion_usuario.php',
                    type: 'POST',
                    data: {
                        id: id,
                        name: name,
                        lastname: lastname,
                        email: email,
                        username: username,
                        password: password
                    },
                    success: function(response){
                        alert("User updated successfully");
                        hideModal("ModalEditar");
                        loadUsers();
                    },
                    error: function(xhr, status, error) {
                        console.error("Error saving edition:", error);
                    }
                });
            }

            function ShowDelete(id_user){
                document.getElementById("ElimID").textContent = id_user;
                document.getElementById("ModalEliminar").style.display = "block";
            }
            
            function DeleteUser(){
                var id = document.getElementById('ElimID').innerText;
                $.ajax({
                    url: 'eliminar_usuario.php',
                    type: 'POST',
                    data: {
                        id_user: id
                    },
                    success: function(response){
                        alert("User deleted successfully");
                        document.getElementById("ModalEliminar").style.display = "none";
                        loadUsers();
                    },
                    error: function(xhr, status, error) {
                        console.error("Error deleting user:", error);
                    }
                });
            }

            function loadUsers() {
                $.ajax({
                    url: 'cargar_ususrios.php',
                    type: 'GET',
                    success: function(response){
                        $('#tabla-usuarios').html(response);
                    },
                    error: function(xhr, status, error) {
                        console.error("Error loading users:", error);
                    }
                });
            }

            $(document).ready(function(){
                // Initialize the table when the view loads
                loadUsers();
            });
        </script>

    </body>
</html>
