<?php
    session_start();
    //define database connection variables
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user_db";

    //create database connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    //verify connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    //verify if the login form has been submitted

    $user = $_POST["username"];
    $pass = $_POST["password"];

    //SQL query to verify username and password
    $sql = "SELECT * FROM users WHERE username='$user' AND password='$pass'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
       $row = $result->fetch_assoc();
       $_SESSION["username"] = $row["username"];
       $_SESSION["id_user"] = $row["id_user"];
       $_SESSION["email"] = $row["email"];
       $_SESSION["name"] = $row["name"];
       $_SESSION["lastname"] = $row["lastname"];
       $_SESSION["password"] = $row["password"];
       header("Location: welcome.php");
       exit();

    } else {
        //login failed
        echo "Incorrect username or password. <a href='index.html'>Try again</a>";
    }
$conn->close();
?>