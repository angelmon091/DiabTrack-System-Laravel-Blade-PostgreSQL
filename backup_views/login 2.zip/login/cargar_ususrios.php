<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user_db";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Dynamically detect the primary key 
            $id = $row['id'] ?? $row['id_usuario'] ?? $row['id_user'] ?? $row['user_id'] ?? array_values($row)[0] ?? 0;
            $id_rol = isset($row['id_rol']) ? $row['id_rol'] : 0;
            
            echo "<tr>
                    <td>" . $id . "</td>
                    <td>" . $row['name'] . "</td>
                    <td>" . $row['lastname'] . "</td>
                    <td>" . $row['email'] . "</td>
                    <td>" . $row['username'] . "</td>
                    <td>" . $row['password'] . "</td>
                    <td>
                        <div class=\"admin-actions\" style=\"flex-direction: row; gap: 0.5rem;\">
                            <button onclick=\"showEditUser({$id}, '" . addslashes($row['name']) . "', '" . addslashes($row['lastname']) . "', '" . addslashes($row['email']) . "', '" . addslashes($row['username']) . "', '" . addslashes($row['password']) . "')\" style=\"background-color: #4f46e5;\">Edit</button>
                            <button onclick=\"ShowDelete({$id})\" style=\"background-color: #e54646ff;\">Delete</button>
                        </div>
                    </td>
                </tr>";
        }
    } else {
        echo '<tr><td colspan="7" class="text-center">No users available</td></tr>';
    }

    $conn->close();
?>
