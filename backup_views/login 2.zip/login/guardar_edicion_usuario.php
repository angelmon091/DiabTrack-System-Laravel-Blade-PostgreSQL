<?php
  session_start();

  $id_user = $_POST['id'];
  $name = $_POST['name'];
  $lastname = $_POST['lastname'];
  $email = $_POST['email'];
  $username = $_POST['username'];
  $password = $_POST['password'];

  $servername = "localhost";
  $username_db = "root";
  $password_db = "";
  $dbname = "user_db";

  $conn = new mysqli($servername, $username_db, $password_db, $dbname);

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $stmt = $conn->prepare("UPDATE users SET name = ?, lastname = ?, email = ?, username = ?, password = ? WHERE id_user = ?");
  $stmt->bind_param("sssssi", $name, $lastname, $email, $username, $password, $id_user);

  if ($stmt->execute()) {
    echo "Record updated successfully";
  } else {
    echo "Error updating record: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
?>