<?php
  session_start();

  if (!isset($_POST['id_user'])) {
      die("ID user not provided");
  }

  $id_user = $_POST['id_user'];

  $servername = "localhost";
  $username_db = "root";
  $password_db = "";
  $dbname = "user_db";

  $conn = new mysqli($servername, $username_db, $password_db, $dbname);

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $stmt = $conn->prepare("DELETE FROM users WHERE id_user = ?");
  $stmt->bind_param("i", $id_user);

  if ($stmt->execute()) {
    echo "Record deleted successfully";
  } else {
    echo "Error deleting record: " . $stmt->error;
  }

  $stmt->close();
  $conn->close();
?>
