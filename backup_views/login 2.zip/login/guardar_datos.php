<?php
    session_start();
    //define database connection variables
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user_db";

    //create database connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    //verify connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    //verify if the registration form has been submitted
    $name = $_POST["name"];
    $lastname = $_POST["lastname"];
    $email = $_POST["email"];
    $user = $_POST["username"];
    $pass = $_POST["password"];

    //SQL query to save the user
    $sql = "INSERT INTO users (name, lastname, email, password, username) VALUES ('$name', '$lastname', '$email', '$pass', '$user')";

    if ($conn->query($sql) === TRUE) {
        header("Location: welcome.php");
        exit();
    } else {
        echo "Error saving data: <a href='registro.html'>Try again</a>" . $conn->error;
    }
    $conn->close();
?>
